﻿using NUnit.Framework;


namespace NewToDoGroup1.Tests
{
    [TestFixture]
    public class TaskServiceTests
    {
        private TaskService service;
        private string testFile = "tasks.txt";

        [SetUp]
        public void Setup()
        {
            if (File.Exists(testFile))
            { File.Delete(testFile); }

            service = new TaskService();
        }

        [Test]
        public void AddTask_ValidNameStatus_ShouldAddTask()
        {
            //Arrange from SetUp

            //Act
                service.AddTask("Make coffee");
            //Assert
            var tasks = service.GetAllTasks();
            Assert.That(1, Is.EqualTo(tasks.Count));
            Assert.That("Make coffee", Is.EqualTo(tasks[0].Name));
            Assert.That(tasks[0].IsCompleted, Is.False);

        }
        [Test]
        public void RemoveTask_ValidIndex_ShouldRemoveTask()
        {
            //Arrange
            service.AddTask("Task1");
            service.AddTask("Task2");
            //Act
            service.RemoveTask(0);
            //Assert
            var tasks = service.GetAllTasks();
            Assert.That(1, Is.EqualTo(tasks.Count));
            Assert.That("Task2", Is.EqualTo(tasks[0].Name));

        }
        [Test]
        public void Edit_ValidIndexName_ShouldUpdateName()
        {
            //Arrange
            service.AddTask("Old Name");
            //Act
            service.Edit(0, "New Name");
            //Assert
            var tasks = service.GetAllTasks();
            Assert.That("New Name", Is.EqualTo(tasks[0].Name));
        }
        [Test]
        public void ChangeStatus_ShouldChangeStatus()
        {
            //Arrange
            service.AddTask("Homework");
            //Act
            var tasks = service.GetAllTasks();
            var firststatus = tasks[0].IsCompleted;
            service.ChangeStatus(0);
            var secondstatus = tasks[0].IsCompleted;
            //Assert
            Assert.That(secondstatus, Is.Not.EqualTo(firststatus));

        }

    }
}
